
import java.util.*;

class Task {
    int id;
    double computationCost; // cost to perform the task
    double deadline; // task deadline

    Task(int id, double computationCost, double deadline) {
        this.id = id;
        this.computationCost = computationCost;
        this.deadline = deadline;
    }
}

class Node {
    int id;
    double processingPower; // processing power of the node
    double costPerUnit; // cost per unit of computation

    Node(int id, double processingPower, double costPerUnit) {
        this.id = id;
        this.processingPower = processingPower;
        this.costPerUnit = costPerUnit;
    }

    double estimateCost(Task task) {
        return task.computationCost * this.costPerUnit;
    }
}

class BlockchainScheduler {
    List<Node> nodes;
    List<Task> tasks;

    BlockchainScheduler(List<Node> nodes, List<Task> tasks) {
        this.nodes = nodes;
        this.tasks = tasks;
    }

    void scheduleTasks() {
        for (Task task : tasks) {
            Node selectedNode = null;
            double minCost = Double.MAX_VALUE;

            // Find the node with the minimum cost that can process the task
            for (Node node : nodes) {
                double cost = node.estimateCost(task);
                if (cost < minCost) {
                    minCost = cost;
                    selectedNode = node;
                }
            }

            if (selectedNode != null) {
                System.out.println("Task " + task.id + " is assigned to Node " + selectedNode.id + " with cost " + minCost);
            } else {
                System.out.println("Task " + task.id + " could not be assigned to any node.");
            }
        }
    }
}

 class HealthcareTaskScheduler {
    public static void main(String[] args) {
        List<Task> tasks = new ArrayList<>();
        List<Node> nodes = new ArrayList<>();

        // Create 100 healthcare tasks with random computation costs and deadlines
        Random random = new Random();
        for (int i = 1; i <= 100; i++) {
            double computationCost = 10 + (100 - 10) * random.nextDouble(); // random cost between 10 and 100
            double deadline = 1 + (10 - 1) * random.nextDouble(); // random deadline between 1 and 10
            tasks.add(new Task(i, computationCost, deadline));
        }

        // Create nodes with different processing power and cost per unit
        nodes.add(new Node(1, 50, 0.5));
        nodes.add(new Node(2, 75, 0.6));
        nodes.add(new Node(3, 100, 0.7));

        // Initialize the scheduler with tasks and nodes
        BlockchainScheduler scheduler = new BlockchainScheduler(nodes, tasks);

        // Schedule the tasks
        scheduler.scheduleTasks();
    }
}
