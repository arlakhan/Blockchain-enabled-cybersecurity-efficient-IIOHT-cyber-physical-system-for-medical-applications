
import java.util.UUID;

public class IIOHTDevice {
    private String deviceId;
    private String deviceType;
    private String data;

    public IIOHTDevice(String deviceType) {
        this.deviceId = UUID.randomUUID().toString();
        this.deviceType = deviceType;
    }

    public String getData() {
        return data;
    }

    public void generateData() {
        // Simulate data generation for a medical device
        this.data = "Device Data: " + deviceType + " - " + Math.random();
    }

    public void sendData(BlockchainModule blockchain) {
        blockchain.blockchain.add(new Block(this.data, blockchain.blockchain.get(blockchain.blockchain.size() - 1).hash));
    }
}
