import java.util.ArrayList;
import java.util.List;

public class CyberSecurityModule {

    public static boolean isMalware(String data) {
        // Simulate malware detection using a predefined set of patterns
        List<String> malwarePatterns = new ArrayList<>();
        malwarePatterns.add("malware");
        malwarePatterns.add("virus");

        for (String pattern : malwarePatterns) {
            if (data.contains(pattern)) {
                return true;
            }
        }
        return false;
    }
}
