import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        BlockchainModule blockchainModule = new BlockchainModule();

        List<IIOHTDevice> devices = new ArrayList<>();
        devices.add(new IIOHTDevice("Heart Monitor"));
        devices.add(new IIOHTDevice("Blood Pressure Monitor"));

        for (IIOHTDevice device : devices) {
            device.generateData();
            if (!CyberSecurityModule.isMalware(device.getData())) {
                device.sendData(blockchainModule);
            } else {
                System.out.println("Malware detected in device data. Skipping...");
            }
        }

        EfficiencyModule.optimizeDataTransmission(devices);

        System.out.println("Blockchain is valid: " + blockchainModule.isChainValid());
    }
}

